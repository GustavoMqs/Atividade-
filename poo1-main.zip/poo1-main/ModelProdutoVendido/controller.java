package controller;

import model.aluno;

public class Controlador{
    private EstoqueProduto[] EstoqueProduto;
    private int Estoque pos;
    private ProdutosCadastradosListarProdutosFrame ProdutosCadastradosListarProdutosFrame;

    public void  CadastrarProdutos(){
    }
    public boolean InserirProduto(){
        return false;
    }
    public void AtualizarProduto(){
    }
    public void ListarProdutos(){
    }
    public void EditarProdutos(){
    }
}

