package controller;

import model.aluno

public class Controlador{
    private EstoqueProduto[] estoqueProduto;
    private Vendas[] vendas;
    private Int estoque pos;
    private Inte vendas pos;
    private ProdutosCadastradosListarProdutosFrame ProdutosCadastradosListarProdutosFrame;
    private ListaVendasFrame ListarProdutosFrame;

    












}